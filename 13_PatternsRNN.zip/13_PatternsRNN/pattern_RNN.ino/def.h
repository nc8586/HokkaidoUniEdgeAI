#include <SPI.h>
#include <SpiRAM.h>

const uint32_t ramSize = 0x1FFFF;           // 128K x 8 bit
const byte LED = 13;

#define lowThershold 100
#define midThershold 200
#define highThershold 400
#define EVALUATION_SIZE 300
#define ML_OFF 1

#define SRAM0 0x100000 // SRAM0の先頭アドレス
#define SRAM1 0x200000 // SRAM1の先頭アドレス

#define GPIO0 0x00
#define GPIO1 0x04
#define GPIO2 0x08
#define GPIO3 0x0c
#define GPIO4 0x10
#define GPIO5 0x14
#define GPIO6 0x18
#define GPIO7 0x1c

#define N_IN  3
#define N_H   30
#define N_OUT 1
#define L_DEPTH 4

#define N_WI (N_IN + 1) * N_H
#define N_WH (N_H  + 1) * N_H
#define N_WO (N_H  + 1) * N_OUT

// 初期化データの総数
#define N_DATA_0 N_WH + N_WO + N_IN + N_OUT + N_OUT
#define N_DATA_1 N_WH + N_WO

#define ADDR_WI_START     0
#define ADDR_WH_START     ADDR_WI_START + N_WI
#define ADDR_WO_START     ADDR_WH_START + N_WH
#define ADDR_INPUT_START  ADDR_WO_START + N_WO
#define ADDR_LABEL_START  ADDR_INPUT_START + N_IN
#define ADDR_OUTPUT_START ADDR_LABEL_START + N_OUT

#define ADDR_WI_END      ADDR_WH_START - 1
#define ADDR_WH_END      ADDR_WO_START - 1
#define ADDR_WO_END      ADDR_INPUT_START - 1
#define ADDR_INPUT_END   ADDR_LABEL_START - 1
#define ADDR_LABEL_END   ADDR_OUTPUT_START - 1
#define ADDR_OUTPUT_END  ADDR_OUTPUT_START + N_OUT - 1

#define ADDR_DEBUG_H_START ADDR_OUTPUT_START + N_OUT
#define ADDR_DEBUG_Y_START ADDR_DEBUG_H_START + N_H
#define ADDR_END           ADDR_DEBUG_Y_START + N_OUT

#define ADDR_DEBUG_H_END   ADDR_DEBUG_Y_START - 1
#define ADDR_DEBUG_Y_END   ADDR_END - 1

void sram_data_init(SpiRAM);
void sram_weight_init(SpiRAM);

void weight_ack(SpiRAM, byte);


void send_operation(SpiRAM, byte);
void print_recieved_data(SpiRAM);

void zero_filling(SpiRAM);

void print_binary(int, int);

void run_neural_network(SpiRAM, byte);

typedef struct circular_buf_t circular_buf_t;
typedef circular_buf_t* cbuf_handle_t;
cbuf_handle_t circular_buf_init(int* buffer, size_t size);
static void advance_pointer(cbuf_handle_t me);
void circular_buf_put(cbuf_handle_t me, int data);
int circular_buf_get_average(cbuf_handle_t me);

void init_in_dat(int in_IR, byte in_dat[N_IN], int seqRecog[L_DEPTH]);
int create_random_data_point();
