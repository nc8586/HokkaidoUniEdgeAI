#include <SPI.h>
#include <SpiRAM.h>
#include "def.h"


// PRINT_BINARY - Arduino
//
// Prints a positive integer in binary format with a fixed withdth
//
// copyright, Peter H Anderson, Baltimore, MD, Nov, '07

void print_binary(int v, int num_places)
{
  int mask=0, n;

  for (n=1; n<=num_places; n++)
  {
    mask = (mask << 1) | 0x0001;
  }
  v = v & mask;  // truncate v to specified number of places

  while(num_places)
  {

    if (v & (0x0001 << num_places-1))
    {
      Serial.print("1");
    }
    else
    {
      Serial.print("0");
    }

    --num_places;
    if(((num_places%4) == 0) && (num_places != 0))
    {
      Serial.print("_");
    }
  }
}





void sram_data_init(SpiRAM sRam){
    uint32_t i = 0;
    byte x0, x1;
    byte buffer[10] = {};

    x0 = B00000000;
    x1 = B00100000;
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START +  0, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START +  1, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START +  2, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START +  3, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START +  4, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START +  5, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START +  6, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START +  7, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START +  8, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START +  9, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START + 10, (char *)&x1, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START + 11, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START + 12, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START + 13, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START + 14, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_INPUT_START + 15, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_LABEL_START +  0, (char *)&x1, 1);
    sRam.writeBuffer(SRAM0 + ADDR_LABEL_START +  1, (char *)&x0, 1);
    sRam.writeBuffer(SRAM0 + ADDR_LABEL_START +  2, (char *)&x1, 1);
    sRam.writeBuffer(SRAM0 + ADDR_LABEL_START +  3, (char *)&x1, 1);

    for(i = ADDR_INPUT_START; i <= ADDR_INPUT_END; i++){
        sRam.readBuffer(SRAM0 + i, (char *)buffer, 1);
        Serial.print(i, HEX);
        Serial.print(", ");
        Serial.print(buffer[0], HEX);
        Serial.println("");
    }

    for(i = ADDR_LABEL_START; i <= ADDR_LABEL_END; i++){
        sRam.readBuffer(SRAM0 + i, (char *)buffer, 1);
        Serial.print(i, HEX);
        Serial.print(", ");
        Serial.print(buffer[0], HEX);
        Serial.println("");
    }
}

// void sram_weight_init(SpiRAM sRam){
//     uint32_t i = 0;
//
//     sRam.writeBuffer(SRAM0 + ADDR_WI_START, wi, N_WI);
//     sRam.writeBuffer(SRAM0 + ADDR_WH_START, wh, N_WH);
//     sRam.writeBuffer(SRAM0 + ADDR_WO_START, wo, N_WO);
//
// }

void sram_weight_init(SpiRAM sRam){
    uint32_t i = 0;

    sRam.writeBuffer(SRAM0 + ADDR_WI_START, (char *)0, N_WI);
    sRam.writeBuffer(SRAM0 + ADDR_WH_START, (char *)0, N_WH);
    sRam.writeBuffer(SRAM0 + ADDR_WO_START, (char *)0, N_WO);

}

// void sram_weight_init(SpiRAM sRam){
//     uint32_t i = 0;
//     int randNum_0;
//     byte randbit_0;
//     byte randbit_1;
//     byte buffer[10] = {};
//
//     // Uniform -4 to +4-2^-5
//     for(i = 0; i <= ADDR_LABEL_END; i++){
//         if(i <= ADDR_WH_END){
//             randNum_0 = random(0, 256);
//             //randbit_0 = (randNum_0 % 64) + ((( (randNum_0 >> 5) % 2) * 3) << 6);
//             randbit_0 = randNum_0;
//             randbit_1 = random(0, 256);
//
//             sRam.writeBuffer(SRAM0 + i, (char *)&randbit_0, 1);
//             sRam.writeBuffer(SRAM1 + i, (char *)&randbit_1, 1);
//         }
//         else if(i <= ADDR_WO_END){
//           randNum_0 = random(0, 256);
//           //randbit_0 = (randNum_0 % 64) + ((( (randNum_0 >> 5) % 2) * 3) << 6);
//           randbit_0 = randNum_0;
//           randbit_1 = random(0, 256);
//
//           sRam.writeBuffer(SRAM0 + i, (char *)&randbit_0, 1);
//           sRam.writeBuffer(SRAM1 + i, (char *)&randbit_1, 1);
//         }
//     }
// }



void weight_ack(SpiRAM sRam, byte flag){
    byte buffer[4] = {};

    sRam.readBuffer(GPIO1, (char *)buffer, 4);
    while(buffer[3] != flag){
        sRam.readBuffer(GPIO1, (char *)buffer, 4);
    }
}


void send_operation(SpiRAM sRam, byte op){
    byte buffer[4];

    buffer[0] = 0x00;
    buffer[1] = 0x00;
    buffer[2] = 0x00;
    buffer[3] = op;
    sRam.writeBuffer(GPIO0, (char *)buffer, 4);
}

void print_recieved_data(SpiRAM sRam){
    byte buffer[50];
    int i;

    Serial.print("GPIO ");
    for(i=0; i<8; i++){
        sRam.readBuffer(i*4, (char *)buffer, 4);
        Serial.print("["); Serial.print(i, DEC); Serial.print("] ");
        Serial.print(buffer[0], HEX); Serial.print(" ");
        Serial.print(buffer[1], HEX); Serial.print(" ");
        Serial.print(buffer[2], HEX); Serial.print(" ");
        Serial.print(buffer[3], HEX); Serial.print("  ");
    }


    /********* 入力表示 *********/
    Serial.print(":  "); Serial.print(SRAM0 + ADDR_INPUT_START, HEX); Serial.print(" ");
    sRam.readBuffer(SRAM0 + ADDR_INPUT_START, (char *)buffer, N_IN);
    for(i = 0; i < N_IN; i++){
        // Serial.print(buffer[i], HEX); Serial.print(" ");
        print_binary(buffer[i], 8);
    }

    /********* ラベル表示 *********/
    Serial.print(":  "); Serial.print(SRAM0 + ADDR_LABEL_START, HEX); Serial.print(" ");
    sRam.readBuffer(SRAM0 + ADDR_LABEL_START, (char *)buffer, N_OUT);
    for(i = 0; i < N_OUT; i++){
        // Serial.print(buffer[i], HEX); Serial.print(" ");
        print_binary(buffer[i], 8);
    }

    /********* 出力結果表示 *********/
    Serial.print(":  "); Serial.print(SRAM0 + ADDR_OUTPUT_START, HEX); Serial.print(" ");
    sRam.readBuffer(SRAM0 + ADDR_OUTPUT_START, (char *)buffer, N_OUT);
    for(i = 0; i < N_OUT; i++){
//        Serial.print(buffer[i], HEX); Serial.print(" ");
        print_binary(buffer[i], 8);
    }

}


void zero_filling(SpiRAM sRam){
    uint32_t i = 0;
    byte buffer[4];
    byte x0 = 0x00;

    /***** BPIO *****/
    for(i=0; i<8; i++){
        buffer[0] = 0x00;
        buffer[1] = 0x00;
        buffer[2] = 0x00;
        buffer[3] = 0x00;
        sRam.writeBuffer(i*4, (char *)buffer, 4);
    }


    /***** SRAM *****/
    for(i = 0; i <= ramSize; i++){
        sRam.writeBuffer(SRAM0 + i, (char *)&x0, 1);
        sRam.writeBuffer(SRAM1 + i, (char *)&x0, 1);
    }
}

void run_neural_network(SpiRAM sRam, byte mode){
    byte op, flag;

    /********** リセット信号書き込み          **********/
    op = 0x10;
    send_operation(sRam, op);

    /********** FPGAコアのリセット完了まで待つ **********/
    flag = 0x10;
    weight_ack(sRam, flag);

    /********** 実行命令書き込み              **********/
    op = mode;
    send_operation(sRam, op);
    Serial.print("OP "); Serial.print(op, HEX); Serial.print(": ");

    /********** 実行完了まで待つ              **********/
    flag = 0x0f;
    weight_ack(sRam, flag);
}

struct circular_buf_t {
  int * buffer;
  size_t head;
  size_t max; //of the buffer
};

cbuf_handle_t circular_buf_init(int* buffer, size_t size)
{
  cbuf_handle_t cbuf = (cbuf_handle_t)malloc(sizeof(circular_buf_t));

  cbuf->buffer = buffer;
  cbuf->max = size;
  cbuf->head = 0;

  return cbuf;
}

static void advance_pointer(cbuf_handle_t me)
{
  if (++(me->head) == me->max) 
  { 
    me->head = 0;
  }
}

void circular_buf_put(cbuf_handle_t me, int data)
{
    me->buffer[me->head] = data; //Put
    advance_pointer(me); //Change head pointer
}

int circular_buf_get_average(cbuf_handle_t me)
{
    unsigned char i = 0;
    int avg, sum = 0;

    for(i; i <= me->max; i++){
      sum = sum + me->buffer[i];
    }
    avg = sum/me->max;

    return avg;
}

void init_in_dat(int in_IR, byte in_dat[N_IN], int seqRecog[L_DEPTH])
{
  for (int i = 0; i < (N_IN); i++) {
      in_dat[i] = B00000000;
      seqRecog[3] = 4;
  }
  if (in_IR > highThershold){
      in_dat[2] = B00100000;
      seqRecog[3] = 3;
  }
  else if (in_IR > midThershold){
      in_dat[1] = B00100000;
      seqRecog[3] = 2;
  }
  else if (in_IR > lowThershold){
      in_dat[0] = B00100000;
      seqRecog[3] = 1;
  }else{
      seqRecog[3] = 0;
  }
}

int create_random_data_point(){
  int randNum = random(3);
  if (randNum == 2){
    return 500;
  }else if (randNum == 1){
    return 300;
  }
  else{
    return 150;
  }
}
