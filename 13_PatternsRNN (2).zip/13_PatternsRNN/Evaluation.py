import numpy
from sklearn import metrics
import matplotlib.pyplot as plt
# Put Serial Output Below
label = [0, 0, 0, 0, 1, 0, 0, 0, 0,  1]
inference = [0, 0, 0, 0, 1, 0, 1, 0, 1, 0]
# Create Matrix
confusion_matrix = metrics.confusion_matrix(label, inference)
# Add Titles
cm_display = metrics.ConfusionMatrixDisplay(
    confusion_matrix=confusion_matrix, display_labels=[False, True])
# Calculate Accuracy
Accuracy = metrics.accuracy_score(label, inference)
# Print to Terminal
print(Accuracy)
# Display Matrix
cm_display.plot()
plt.show()
